import React from 'react'
import './midSection.css'

export const MidSection = () => {
  return (
    <div className='bg-image'>

    </div>
  )
}