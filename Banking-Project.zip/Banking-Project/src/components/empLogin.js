import { useState } from "react"
import { useNavigate } from "react-router"
import { Link } from "react-router-dom"
const EmpLogin = () => {
    let [empname,setname] = useState("")
  let [password,setpasswordword] = useState("")
  let [role,setRole] = useState("")
  let [data,setData] = useState("")
  let navigate = useNavigate()

  function loginHandler(event)
  {
        console.log({empname,password})
        console.log(role)
      if(role==="employee"){

        event.preventDefault();
        const getData = async () => {
           
            const obj = await fetch("http://localhost:5000/login/:empname/:password" +empname + "/" + password)
            // console.log(obj)
            const arr = await obj.json();
            console.log(arr);
            
             if(arr.length){
  
                // alert("welcome");
                const data=JSON.stringify(arr[0]);
                localStorage.setItem("obj",data);
                navigate("/customerDetails");
            }
            else {
               alert("Invalid username or passwordword.");
            }
                
            setData(arr[0]);
    
    
    
      }
      getData()
    }
}
  return (
<div>
    <div className='container container fluid '>
    <h1 className="text-center text-info mb-2">Login Here...</h1>
        <form className="form shadow p-3 mb-5 bg-body rounded">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Employee Name</label>
    <input type="text" class="form-control" aria-describedby="emailHelp"/>
    
  </div>
  <div class="mb-3">
    <label for="exampleInputpasswordword1" class="form-label">password</label>
    <input type="passwordword" class="form-control" />
  </div>
   
  <Link to="/customerDetails"> <button type="submit" class="btn btn-success" onChange={loginHandler}>Emp Login</button></Link>

  </form>
</div>
</div>
  )
}

export default EmpLogin