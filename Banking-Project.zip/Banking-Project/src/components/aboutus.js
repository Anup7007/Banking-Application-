import React from 'react'
import './AboutUs.css'
import { Link } from 'react-router-dom'
const AboutUs = () => {
    return (
        <div class="about">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-img">
                            <iframe width="450" height="250" src="https://youtu.be/IZnqsVGBFik" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-content">
                            <div class="section-header">
                                <p>About Us</p>
                                <h2>Working Since 2000</h2>
                            </div>
                            <div class="about-text">
                               <p>Citi began operations in India over a century ago in 1902 in Kolkata and today is a significant foreign investor in the Indian financial market. As promoter-shareholder, Citi has played a leading role in establishing important market intermediaries such as depositories, credit bureau, clearing and payment institutions.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default AboutUs