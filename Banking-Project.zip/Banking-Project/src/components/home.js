import React from 'react'
import {MidSection} from './midSection'

const Home = () => {
  return (
    <div>
      <MidSection/>
    </div>
  )
}

export default Home