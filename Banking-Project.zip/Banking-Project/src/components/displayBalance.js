import React, { useEffect, useState } from 'react'
import $ from 'jquery'
import { ReactDOM } from 'react-dom'

function DisplayBalance() {
    const [customer, setCustomer]=useState([]);
    useEffect( ()=>{
        // console.log("hello")

        
       async function getData(){
  
            try{
                const output = await fetch("http://localhost:5000/getcustomer") 

                const cons= await output.json()

                setCustomer(cons);
       
            } catch (err) {
                console.log(err)
            }
          
        }

        getData()
    },[])
  return (
    <div class="container">
    <table class="table table-bordered">
        <thead class="table-primary">
        <tr>
            <th scope="col">Id</th> 
            <th scope="col">Name</th>
            <th scope="col">Account Balance</th>
            
          </tr>
        </thead>
        <tbody>
            

        {
            customer.map((data)=>
                <tr>
                    <td>{data.id}</td>
                    
                    <td>{data.name}</td>
                   
                    <td>{data.account_balance}</td>
                  

                </tr>
            )
        }
           
        </tbody>
      </table>
    
  </div>
  )
}

export default DisplayBalance
