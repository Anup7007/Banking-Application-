import axios from 'axios'
import React from 'react';
function AddCustomer() {
    const handleSubmit = async (event) => {
        event.preventDefault()
        alert("Customer Account Added");
        const account_number = document.getElementById("anum").value;
        const name = document.getElementById("name").value;
        const age = document.getElementById("age").value;
        const address = document.getElementById("address").value;
        const city = document.getElementById("city").value;
        const email = document.getElementById("email").value;
        const mobile_number = document.getElementById("mnum").value;
        const account_balance = document.getElementById("balance").value;


        const object = { account_number: account_number, name: name, age: age, address: address, city: city, email: email, mobile_number: mobile_number, account_balance: account_balance }
        console.log(object);
        try {
            const obj = await axios.post("http://localhost:5000/addcustomer", object)
            console.log(obj.data)
        }
        catch (err) {
            console.log(err)
        }

    }




    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="col">
                        <form>

                            <h1 className="text-secondary text-center">Add Customer</h1>
                            <div className="form-group mb-3">
                                <label for="name">Account Number</label>
                                <input type="text" id="anum" className="form-control" placeholder="*Enter Account Number" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="name">Customer Name</label>
                                <input type="text" id="name" className="form-control" placeholder="enter your Name" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="Age">Age</label>
                                <input type="text" id="age" className="form-control" placeholder="enter your Age" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="address">Customer Address</label>
                                <input type="text" id="address" className="form-control" placeholder="enter Address" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="city">City</label>
                                <input type="text" id="city" className="form-control" placeholder="enter City" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="email">Email Id</label>
                                <input type="text" id="email" className="form-control" placeholder="enter Email Id" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="email">Mobile Number</label>
                                <input type="text" id="mnum" className="form-control" placeholder="enter Mobile Number" />
                            </div>

                            <div className="form-group mb-3">
                                <label for="balance">Account Balance</label>
                                <input type="text" id="balance" className="form-control" placeholder="enter your Account Balance" />
                            </div>





                            <div className="form-group  mt-5">

                                <input type="button" className="btn btn-primary" value="Add " onClick={handleSubmit} />
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}


export default AddCustomer