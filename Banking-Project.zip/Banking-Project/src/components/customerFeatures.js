import React from 'react'
import { Link } from 'react-router-dom'

const CustomerFeatures = () => {
  return (
    <div className="container-fluid mt-5 bg1">
          <h1 className='d-flex justify-content-center mb-5 '>
      Customer Features
          </h1>
          <div className="container d-flex justify-content-center mt-10">
          <Link to="/displayBalance" className='px-4'> <input type="button" value="Customer Balance" className="btn btn-info"></input></Link>
          </div>
    </div>
  )
}

export default CustomerFeatures