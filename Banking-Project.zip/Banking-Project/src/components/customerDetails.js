import React from 'react'
import { Link } from 'react-router-dom'

const CustomerDetails = () => {
  return (
    <div className="container-fluid mt-5 bg1">
      <h1 className='d-flex justify-content-center mb-5 '>
      Customer Details
          </h1>
          <div className="container d-flex justify-content-center mt-10">
          <Link to="/addCustomer" className='px-4'> <input type="button" value="Add Customer" className="btn btn-success "></input></Link>
          <Link to="/displayCustomer" className='px-4'> <input type="button" value="Display Customer" className="btn btn-info"></input></Link>
          </div>
    </div>
  )
}

export default CustomerDetails