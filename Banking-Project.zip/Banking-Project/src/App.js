import './App.css';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Nav from './components/nav';
import EmpLogin from './components/empLogin';
import CustomerDetails from './components/customerDetails';
import AddCustomer from './components/addCustomer';
import DisplayCustomer from './components/displayCustomer';
import Customer from './components/customer';

import Home from './components/home';
import Aboutus from './components/aboutus';
import CustomerFeatures from './components/customerFeatures';
import DisplayBalance from './components/displayBalance';




function App() {
  return (
   <div>
    <BrowserRouter>
    <Nav/>
    <Routes>
    <Route path='/home' element={<Home />} />
    <Route path='/aboutus' element={<Aboutus />} />
    <Route path='/empLogin' element={<EmpLogin />} />
    <Route path='/customerDetails' element={<CustomerDetails />} />
    <Route path='/addCustomer' element={<AddCustomer />} />
    <Route path='/displayCustomer' element={<DisplayCustomer />} />
    <Route path='/customer' element={<Customer />} />
    <Route path='/customerFeatures' element={<CustomerFeatures />} />
    <Route path='/displayBalance' element={<DisplayBalance />} />
 
    </Routes>
    </BrowserRouter>
   </div>
  );
}

export default App;
