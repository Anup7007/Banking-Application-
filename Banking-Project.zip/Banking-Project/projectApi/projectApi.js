const Express=require("express")
const con =require("./connection");
const app= Express(); 
const cors = require('cors')
app.use(cors());

//get Customer
  app.get("/getcustomer",(req,res)=>{
    con.query("select * from savingsAccount",function(err,result){
      if(err){
        res.send("error")
      }else{
        res.send(result)
      }
    })
  })

 
// Add new customer api
  const bodyParser = require('body-parser'); 
  app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post("/addcustomer",(req,resp)=>{
  const data=req.body;
  console.log(req.body);
  con.query('insert into savingsAccount (account_number,name,age,address,city,email,mobile_number,account_balance) values (?,?,?,?,?,?,?,?)',[req.body.account_number,req.body.name,req.body.age,req.body.address,req.body.city,req.body.email,req.body.mobile_number,req.body.account_balance],(error,result,fields)=>{

    if(error)
          console.log("error is "+error);
      else
      {
         return resp.json(data);

      }
  });
})

//customer login-----//
app.get("/login/:ac_num/:password",(req,res)=>{
  let ac=req.params.ac_num;
  let password=req.params.password;
  con.query("select ac_num,name,deposit,address from customer where ac_num=? and password=?",[ac,password],function(err,result){
    if(err){
      res.send("error")
    }else{
      res.send(result)
      return result;
    }
  })
})

//Employee Login
app.get("/login/:ac_num/:password",(req,res)=>{
  let ac=req.params.ac_num;
  let password=req.params.password;
  con.query("select ac_num,name,deposit,address from employee where ac_num=? and password=?",[ac,password],function(err,result){
    if(err){
      res.send("error")
    }else{
      res.send(result)
      return result;
    }
  })
})


//search api for see current balance by providing acc/ no
app.get("/getcustomer/search/:account_number",(req,res)=>{
  let account_number=req.params.account_number;
  con.query("select * from savingsAccount where account_number=?",[account_number],function(err,result){
    if(err){
      res.send("error")
    }else{
      res.send(result)
    }
  })
})
app.listen(5000,(err)=>{
    if(err){
      console.log(err);
    }else{
      console.log("on port 5000")
    }
  })